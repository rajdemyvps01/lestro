<p align="center">
<a href="https://github.com/Sten-X/Marin-Kitagawa-MD">
    <img src="https://images2.alphacoders.com/120/thumb-1920-1202696.jpg">
  </a>

<h1 align="center"> Marin Kitagawa MD
</h1>

<p align="center"> 
<b>Konnichiwa Senpai, I am "Marin Kitagawa" an Opensource WhatsApp bot made by <a href="https://github.com/Sten-X">Sten-X</a> and his own project "Marin Kitagawa" to do everything that's beyond imagination with highest <b>Features</b> and <b>Stability</b> and <b>Compatibility</b> built with Baileys Multi Device support.

<h3 align="center"> Marin Kitagawa MD - The Future Is Here
</h4>

<br>

<p align="center">
  <a href="https://github.com/Sten-X/Marin-Kitagawa-MD/fork">
    <img src="https://img.shields.io/github/forks/Sten-X/Marin-Kitagawa-MD?label=Fork&style=social">
    
    
  <a href="https://github.com/Sten-X/Marin-Kitagawa-MD/stargazers">
    <img src="https://img.shields.io/github/stars/Sten-X/Marin-Kitagawa-MD?style=social">
  </a>

<br>

<a href="https://github.com/Sten-X/Marin-Kitagawa-MD">
    <img src="https://visitor-badge.glitch.me/badge?page_id=https://github.com/Sten-X/Marin-Kitagawa-MD visitor-badge&left_text=Total%20People%20Visited">
  </a>
  <br><br>
  
      
 
<h4 align="center"> Deploy on Repl.it - ( YouTube Tutorial Included & Highly Recommended )
</h4>

<p align="center" >
    <a href="https://repl.it/github/Sten-X/Marin-Kitagawa-MD">
    <img src="https://i.ibb.co/zrB5kMh/deploy-on-repl.jpg" width="170px" alt="Deploy on Heroku" >
    </a>
    <br>     
    <a href="https://youtu.be/R-_DU73UH8Q"><img src="https://i.ibb.co/71mYRh4/116-1161192-podcast-subscribe-listen-button-youtube-sign-hd-png.png" alt="Watch tutorial on YouTube" border="0"  width="105">
    </a>
</p>

<p align="center" >
    <br>
    __________________________
    <br>
</p>
     
<h4 align="center"> Deploy on Railway - ( YouTube Tutorial Included )
</h4>
  
<p align="center">
    <a href="https://railway.app/new/template/Gts2Zx?referralCode=f3gg2m">
    <img src="https://railway.app/button.svg" alt="Deploy on Railway" width="170px">
    </a>
    <br>
    <a href="https://youtu.be/Qs6ryWnEtu8"><img src="https://i.ibb.co/71mYRh4/116-1161192-podcast-subscribe-listen-button-youtube-sign-hd-png.png" alt="Watch tutorial on YouTube" border="0"  width="105">
    </a>
</p>

<p align="center" >
    <br>
    __________________________
    <br>
</p>

<br>
      
<h4 align="center"> Deploy on Koyeb - ( YouTube Tutorial Included )
</h4>
      
<p align="center">
    <a href="https://app.koyeb.com/deploy?type=docker&image=quay.io/sten-x/marin-kitagawa-md:latest&env[PORT]=8000&env[PREFIX]=.&env[MONGODB]=&env[SESSION_ID]=&env[MODS]=&env[PACKNAME]=Marin-MD&env[AUTHOR]=Sten-X&name=stenx">
    <img src="https://www.koyeb.com/static/images/deploy/button.svg" alt="Deploy on Koyeb" width="155px">
    </a>
   <br>     
    <a href="https://youtu.be/OvNnpK1Gx6Y"><img src="https://i.ibb.co/71mYRh4/116-1161192-podcast-subscribe-listen-button-youtube-sign-hd-png.png" alt="Watch tutorial on YouTube" border="0"  width="105">
    </a>
</p>

<p align="center" >
    <br>
    __________________________
    <br>
</p>


<br>
 <!--   
<h4 align="center"> Deploy on Heroku ( Isn't Working it will be fixed soon ! )
</h4>

</p>

<p align="center" >
    <a href="https://heroku.com/deploy?template=https://github.com/Sten-X/Marin-Kitagawa-MD">
    <img src="https://www.herokucdn.com/deploy/button.png" width="160px" alt="Deploy on Heroku" >
    </a>

https://youtu.be/R-_DU73UH8Q
</p> -->




<br>
<h4 align="center"> Facing Trouble? Join my WhatsApp Group for Support.
</h4>

<p align="center" >
<a href="https://chat.whatsapp.com/Cx1scYCxNhf29QS9BWuvrp"><img src="https://img.shields.io/badge/Join Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" width="140px">
</a>
</p>
<br>
      
<p align="center" >
    <br>
    __________________________
    <br>
</p>  
<br>

<h2 align="center">⚡️ Marin Kitagawa MD Platform Compatibility ⚡️
</h2>

- Marin Kitagawa offers highest platform compatibility.
- Just deploy and use on your favourite platform.
- More Platform comaptibility coming soon...
<br>

      
|    Platform      | :white_check_mark: Pros          |:x: Cons  |
| ----------- | ------------------ |-------|
| <b>Repl.it<b>   | - <b><i>Fastest Deloy.<br> - Faster than Railway / Koyeb. <br> - 24*7 work. <br> - No Crash and auto reboot.<br> - 100% Commands work.<b><i> | <b><i> - No Cons. Just Deploy and Have fun.<b><i>
| <b>Railway<b>    | - <b><i>Fast Deloy.<br> - Faster than Koyeb. <br> - 24*7 work. <br> - Auto Reboot on Crash.<br> - 100% Commands work.<b><i>    | <b><i> - Requires a 6 months old GitHub Account to verify.<br> - 500 hours per month usage.<br> - Crashing Due to 500 mb limited RAM. <br> - Not suitable for newly joined users.<b><i>
| <b>Koyeb<b>   | - <b><i>24*7 work. <br> - Less Crash and auto reboot.<br> - 100% Commands work<b><i> | <b><i> - Now Credit Card required to create account.<br> - Slowest deploy ( Takes Upto 7-8 minutes ).<br> - Slowest work compared to Repl.it / Railway.<br> - Not suitable for newly joined users.<b><i>
| <b>UserLand<b>   | <b><i>No Pros to mention, Only 100% Commands work.<b><i> | <b><i> - Very hard Installation process.<br> - Time consuming deploy process (upto >30 minutes).<br> - Speed depend on your internet.<br> - Will consume too much data.<br> - Nightmare for Beginners.<br> - Prone to error if steps are not followed correctly.<br><b><i>
| <b>Heroku ( Not Compatible )<b> | :x: |:x:|
| <b>Termux ( Useless for all Bots)<b> | :x: |:x:|

<br><br>

<h2 align="center">🎀 Key Features 🎀
</h2>

<br>

- Read [PublicKeys.md](https://github.com/Sten-X/Marin-Kitagawa-MD/blob/main/PublicKeys.md) to use our `provided public keys` if you are lazy to create your own. We have already provided everying you need to run the bot.
- Changeable between `6 added Characters` ( Marin Kitagawa MD, Makima MD, Chika MD, Miku MD, Atlas MD, YOR MD) and more can be added by user inside `BotCharacters.js` file. Type `charlist` command to get character list.
- Fully powered by MongoDb ( 3 databases added ).
- Self / Public / Private mode.
- Single prefix ( "-" ).
- RPG , Economy , Card And Pokemon... So on CMD added ( More coming soon ).
- Group Chatbot / Dm Chatbot ( Only reply on quoted messages and and be turned off ).
- 100+ NSFW commands ( Using my own API ). 
- Highest Commands and Features.
- User Banning / Group Banning.
- Highest Security compared to most other public bots.

<br>


<h2 align="center">〽️ Why Should You Use Marin Kitagawa as your main Bot 〽️
</h2>

<br>

- Marin Kitagawa is a `Highly Maintained` bot which means `Very Stable`.
- Marin Kitagawa is a `multi character bot` which means you can `change bot's character` to any of the 6 added characters or add more characters by yourself.
- Marin Kitagawa is a `multi database bot` which means you can use 3 different databases at the same time.
- Marin Kitagawa is a `multi mode` bot which means you can use it in `Self / Public / Private` mode.
- Marin Kitagawa has a pre installed chatbot which means you can use it as a `group chatbot and dm chatbot`.
- Marin Kitagawa has `Highest NSFW (100+)` which means you can use it as a `nsfw bot`.
- Marin Kitagawa has 300+ commands.
- Marin Kitagawa doesn't store your `Session File` locally which means it's `safe` and `secure`.
- Marin Kitagawa has `RPG , Economy , Card And Pokemon` which means you can use it as a `RPG Bot` or `Casino Bot or Gaming Bot`.
- Marin Kitagawa has `User Banning / Group Banning` which means you can use it as a `Anti Spam Bot`.
- Atlas is a Folder Type bot which represents `Highest Stability`, `Highest Performance` and `Developer / User friendly`.
- Marin Kitagawa comes with [MIT](https://github.com/Sten-X/Marin-Kitagawa-MD/blob/main/LICENSE.md) License which means you can use it as a `base for your own bot` and can `modify it as you want` and can `add your own features`.

<br>

<h2>💫 Project Dependencies :
</h2>
<br>

- [Baileys Library](https://github.com/adiwajshing/Baileys)
<br>

<h2 align="center">🧩 UserLand Deployment Method ( Not Recommented! Use Repl.it insted! ) 🧩
</h2>

#### ⚜️ Download `UserLand` application old version ( 3.1.2 ) from [Here](https://m.apkpure.com/userland-linux-on-android/tech.ula/variant/3.1.2-APK).
#### ⚜️ Install `Debian` terminal in userland.
#### ⚜️ Rename `.env.example` to `.env` and fill in the required details in `.env` file and `config.js` (Mandatory).

</p>

### UserLand commands:


```
sudo apt update
sudo apt upgrade
sudo apt install bash
sudo apt-get install libwebp-dev
sudo apt install git
sudo apt install nodejs -y
sudo apt install ffmpeg -y
sudo apt install wget
sudo apt install npm
sudo apt install imagemagick

git clone https://github.com/Sten-X/Marin-Kitagawa-MD

ls
cd Marin-Kitagawa-MD
npm i


cd
npm install --global yarn
yarn add sharp
sudo apt install curl


curl -sL https://deb.nodesource.com/setup_24.x | sudo -E bash -


sudo apt-get install -y nodejs
yarn add sharp
cd Marin-Kitagawa-MD
npm i
npm start

``` 
- Note in `git clone <my bot's repo>` section your can use Your customised bot's github link too (For that make sure you [Forked](https://github.com/Sten-X/Marin-Kitagawa-MD/fork) this repo and modified `.env` file and `config.js`).
- This method will work on most other bots too.

#### 📌 To stop a bot in Userland
- Tap on `CTRL` button then tap on `C` from keyboard

#### 📌 To start bot again ( While you are inside Atlas-MD folder {use `cd Marin-Kitagawa-MD` to get inside the folder} )
- `npm start` or use `yarn start` to start bot again.


#### 📌 Start bot after UserLand session is cleared
```
cd Atlas-MD
npm start
```
#### 📌 What to do if you logged out from the WhatsApp linked device section and want to get new qr or code to login
- Go to your GitHub fork of this bot and open `.env` file and change `SESSION_ID` to any random string and save it by clicking on `Commit Changes`.
- Then open `UserLand` and run these commands one-by-one:

```
cd Atlas-MD
git fetch origin
git merge origin/main
npm start
```


#### ⚜️ Note as UserLand is a physical server so you must keep on your internet connection active to make sure bot works. Otherwise bot will be down.
<br><br>


<h2 align="center">🧩 CMD / VS Code / Powershell / Terminal Deployment Method 🧩
</h2>

- [Download Updated code](https://github.com/Sten-X/Marin-Kitagawa-MD/archive/refs/heads/main.zip) from Main GitHub Repo or Download from your Forked Repo.
- Extract the `.zip` and open Vs code / Cmd / Powershell / Terminal in that directory and give thesse following commands one-by-one:
- Rename `.env.example` to `.env` and fill in the required details in `.env` file and `config.js` (Mandatory).

```
npm i
npm start
```

- To get new QR or PAIRING CODE if you logged out from the WhatsApp linked device section go to `.env` file and change `SESSION_ID` to any random string and save it by clicking on `Commit Changes`.

### ✧ Requirements for CMD/VS code istallation:
- [Node.js](https://nodejs.org/en/download/)
- [Git](https://github.com/git-guides/install-git)
- FFmpeg ( [for Windows](https://www.geeksforgeeks.org/how-to-install-ffmpeg-on-windows/) or [for Linux](https://www.tecmint.com/install-ffmpeg-in-linux/) or [for Mac](https://ffmpeg.org/download.html) )
- Libwebp (Not necesary for Windows).

Note: If you don't pre-install these plugins before CMD / VS code Installation bot will not start!
</br> 

<h2 align="center">🧣 Contributors 🧣
</h2>

- Check [Project Contributors](https://github.com/Sten-X/Marin-Kitagawa-MD/graphs/contributors)
- Feel free to contribute in this project. I will merge your respected contribution after reviewing it.


<h2 align="center">⚠️ Warning ⚠️
</h2>

<br>

- This bot is not made by WhatsApp.inc so overusing this bot may result in WhatsApp account ban.
- We will only assist you in `Bot Deployment ( Installation or Hosting )`. Not in `Bot Development`.
- If you Modify this bot and face any issues, I am not responsible for that because it's not possible for me or my team to help everyone in bot Development / Modification. Only modify if you know what you are doing.
- This bot is made for `Educational / Fun / Group Management` purposes only. I and the team will not be responsible for any misuse of this bot.
- We will only assist you in `Setup / Deployment` of this bot.

<br>

<h2 align="center">📛 Legal Disclaimer 📛
</h2>
<br>

- We suggest you to use your `Own MongoDB URL` while deploying inside `.env` or `Environment Variables`. That will increase your Privacy and Security.
- We don't recommend to change the `Economy database` we have added inside script. `If you do so, you will be responsible for any issues and we will not provide any support`.
- We will not be responsible for any issues caused by any individual hosting this bot and cause any harm to any Group `(So don't make someone Group Admin who you don't know just because they are hosting the Bot)`.
